-------------------------------------------------------------------
Series ID: A229RX0
Archival Federal Reserve Economic Data, Federal Reserve Bank of St.
Louis
Link: https://alfred.stlouisfed.org/series?seid=A229RX0
Help: https://alfred.stlouisfed.org/help
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
Output Format: Observations by Vintage Date, All Observations
File Created: 2026-09-24 6:11 PM CDT
-------------------------------------------------------------------

-------------------------------------------------------------------  ---------------  -------------
Title                                                                Real-Time Start  Real-Time End
Real Disposable Personal Income: Per Capita                          2010-05-28       Current
Source
U.S. Bureau of Economic Analysis                                     2010-05-28       Current
Release
Personal Income and Outlays                                          2010-05-28       Current
Units
Chained 2012 Dollars                                                 2018-07-31       2023-09-28
Chained 2017 Dollars                                                 2023-09-29       Current
Frequency
Monthly                                                              2010-05-28       Current
Seasonal Adjustment
Seasonally Adjusted Annual Rate                                      2010-05-28       Current
Notes
BEA Account Code: A229RX A Guide to the National Income and Product  2017-10-30       Current
Accounts of the United States (NIPA) -
(http://www.bea.gov/national/pdf/nipaguid.pdf)
-------------------------------------------------------------------  ---------------  -------------

Vintage Dates Specified:
----------
2018-09-07
2018-10-07
2020-09-04
2020-10-04
2022-09-09
2022-10-09
2024-09-06
2024-10-06
2026-09-24
----------

